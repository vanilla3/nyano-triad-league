# Screenshots Guide (optional)

UI改善を依頼する場合、以下の5枚があると理解が非常に速いです。

1) /match  
2) /stream  
3) /overlay?controls=0 (OBS想定)  
4) /overlay?controls=1 (配信者用詳細)  
5) /replay

保存先: `screenshots/` フォルダを作り、png/jpeg を入れてください。
`make_handoff_pack` は `screenshots/` があれば一緒に zip します。

